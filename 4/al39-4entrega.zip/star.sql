DROP TABLE IF EXISTS d_utilizador CASCADE;
DROP TABLE IF EXISTS d_tempo CASCADE;
DROP TABLE IF EXISTS d_local CASCADE;
DROP TABLE IF EXISTS d_lingua CASCADE;
DROP TABLE IF EXISTS f_anomalia CASCADE;

CREATE TABLE d_utilizador
   (id_utilizador           INTEGER     	NOT NULL,
    email 	                VARCHAR(255)	NOT NULL,
    tipo 	                VARCHAR(255)	NOT NULL,
    PRIMARY KEY(id_utilizador)
    );

CREATE TABLE d_tempo
   (id_tempo                INTEGER     	NOT NULL,
    dia                     INTEGER     	NOT NULL,
    dia_da_semana           INTEGER     	NOT NULL,
    semana                  INTEGER     	NOT NULL,
    mes                     INTEGER     	NOT NULL,
    trimestre               INTEGER     	NOT NULL,
    ano                     INTEGER     	NOT NULL,
    PRIMARY KEY(id_tempo)
    );

CREATE TABLE d_local
   (id_local                INTEGER     	NOT NULL,
    latitude                FLOAT         	NOT NULL,
    longitude               FLOAT        	NOT NULL,
    nome 	                VARCHAR(255)	NOT NULL,
    PRIMARY KEY(id_local)
    );

CREATE TABLE d_lingua
   (id_lingua               INTEGER     	NOT NULL,
    lingua 	                VARCHAR(255)	NOT NULL,
    PRIMARY KEY(id_lingua)
    );


CREATE TABLE f_anomalia
   (id_utilizador           INTEGER     	NOT NULL,
    email 	                VARCHAR(255)	NOT NULL,
    tipo 	                VARCHAR(255)	NOT NULL,
    PRIMARY KEY(id_utilizador),
    FOREIGN KEY(email) REFERENCES utilizador(email) ON DELETE CASCADE);

    CREATE TABLE incidencia
   (anomalia_id 	        INTEGER         NOT NULL,
    item_id 	            INTEGER         NOT NULL,
    email 	                VARCHAR(255)	NOT NULL,
    PRIMARY KEY(anomalia_id),
    FOREIGN KEY(anomalia_id) REFERENCES anomalia(id) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY(item_id) REFERENCES item(id) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY(email) REFERENCES utilizador(email) ON DELETE CASCADE);
